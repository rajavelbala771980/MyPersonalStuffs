import React, { FC } from "react";

const AnotherScreen: FC = () => {
  return <div>Hello World! Another Screen</div>;
};

export default AnotherScreen;