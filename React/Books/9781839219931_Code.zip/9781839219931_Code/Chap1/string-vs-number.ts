// let a = 5;
// let b = '6';

// console.log(a + b);

let a: number = 5;
let b: number = 6;
console.log(a + b);