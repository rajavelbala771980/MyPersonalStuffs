namespace constants {
    const val1 = 1;
    val1 = 2;

    const val2 = [];
    val2.push("hello");
}