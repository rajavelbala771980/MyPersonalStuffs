// let val: any = 22;
// val = "string value";
// val = new Array();
// val.push(33);

// console.log(val);

// let val: any = 22;
// val = "string value";
// val = new Array();
// val.doesnotexist(33);

// console.log(val);