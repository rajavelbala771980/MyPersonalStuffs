let unionObj: null | { name: string } = null;
unionObj = { name: 'jon'};

console.log(unionObj);