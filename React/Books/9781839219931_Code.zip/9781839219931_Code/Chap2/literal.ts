let literal: "tom" | "linda" | "jeff" | "sue" = "linda";
literal = "sue";
//literal = "john";
console.log(literal);