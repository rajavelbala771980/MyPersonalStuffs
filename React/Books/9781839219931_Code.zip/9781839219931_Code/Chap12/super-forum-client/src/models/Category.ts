export default class Category {
  constructor(public id: string, public name: string) {}
}
